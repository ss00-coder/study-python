import random as r
# 1부터 10까지 중 랜덤한 정수 1개
# r.randint(inclusive_start, inclusive_end)
print(r.randint(1, 10))
