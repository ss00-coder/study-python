import calc_add
import calc_add as c
import calc.calc_sub as cc
from calc_add import add, getTotal
from calc_add import *

print(calc_add.add(1, 2))
print(c.add(1, 3))
print(cc.sub(1, 4))
print(add(3, 4))
print(getTotal(1, 2, 3))
