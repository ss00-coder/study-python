# start=0 (기본값), step=1 (기본값)

# for i in range(0, 10, 1):
# for i in range(0, 10):
for i in range(10):
    print(f"{i + 1}.한동석")

# 100 ~ 1까지 출력
# for i in range(100, 0, -1):
#     print(i)

for i in range(100):
    print(100 - i)

