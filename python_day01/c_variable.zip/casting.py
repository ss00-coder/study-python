data = 10
print(bin(data))
print(oct(data))
print(hex(data))
print(float(data))

data = 10.93
print(int(data))
print(type(str(data)))

print(bool(1))
print(bool(0))
print(bool(100))
print(bool(""))
print(bool("A"))
