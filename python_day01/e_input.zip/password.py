import getpass

password = getpass.getpass(prompt="password: ")
print(f"{password}")
