if __name__ == '__main__':
    print("Lovely Python!")
else:
    print(__name__)
